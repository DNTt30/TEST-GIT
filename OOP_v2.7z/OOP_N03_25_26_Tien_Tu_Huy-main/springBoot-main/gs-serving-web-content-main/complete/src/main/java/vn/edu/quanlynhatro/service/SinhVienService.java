package vn.edu.quanlynhatro.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import vn.edu.quanlynhatro.model.SinhVien;
import vn.edu.quanlynhatro.repository.SinhVienRepository;

import java.util.List;
import java.util.Optional;

@Service
public class SinhVienService {

    @Autowired
    private SinhVienRepository sinhVienRepository;

    public List<SinhVien> getAllSinhVien() {
        return sinhVienRepository.findAll();
    }

    public Optional<SinhVien> getSinhVienByMssv(String mssv) {
        return sinhVienRepository.findByMssv(mssv);
    }

    public Optional<SinhVien> getSinhVienById(Long id) {
        return sinhVienRepository.findById(id);
    }

    public List<SinhVien> searchSinhVien(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllSinhVien();
        }
        return sinhVienRepository.findByMssvOrHoTenContaining(keyword.trim());
    }

    public SinhVien saveSinhVien(SinhVien sinhVien) {
        return sinhVienRepository.save(sinhVien);
    }

    public void deleteSinhVien(Long id) {
        sinhVienRepository.deleteById(id);
    }

    public void deleteSinhVienByMssv(String mssv) {
        Optional<SinhVien> sinhVien = sinhVienRepository.findByMssv(mssv);
        sinhVien.ifPresent(sv -> sinhVienRepository.delete(sv));
    }

    public boolean isMssvExists(String mssv) {
        return sinhVienRepository.existsByMssv(mssv);
    }

    public List<SinhVien> getSinhVienByLop(String lop) {
        return sinhVienRepository.findByLop(lop);
    }

    public List<SinhVien> getSinhVienByNganhHoc(String nganhHoc) {
        return sinhVienRepository.findByNganhHoc(nganhHoc);
    }

    public long countAllSinhVien() {
        return sinhVienRepository.count();
    }
}