package vn.edu.quanlynhatro.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import vn.edu.quanlynhatro.model.TaiKhoan;
import vn.edu.quanlynhatro.repository.TaiKhoanRepository;

import java.util.List;
import org.springframework.transaction.annotation.Transactional;

@Transactional
/**
 * Lớp TaiKhoanService quản lý các nghiệp vụ liên quan đến tài khoản
 * như đăng nhập, đăng ký, cập nhật, và xóa tài khoản.
 */
@Service
public class TaiKhoanService {

    @Autowired
    private TaiKhoanRepository repo;

    /**
     * Lấy toàn bộ danh sách tài khoản từ cơ sở dữ liệu
     */
    public List<TaiKhoan> getAllTaiKhoan() {
        return repo.findAll();
    }

    /**
     * Tìm tài khoản theo tên đăng nhập
     */
    public TaiKhoan timKiemTheoUsername(String username) {
        return repo.findByUsername(username);
    }

    /**
     * Đăng ký tài khoản mới
     */
    public void dangKy(TaiKhoan tk) {
        repo.save(tk);
    }

    /**
     * Cập nhật mật khẩu và vai trò tài khoản
     */
    public void updateUser(String username, String password, String role) {
        TaiKhoan tk = repo.findByUsername(username);
        if (tk != null) {
            // CHỈ cập nhật password nếu có giá trị mới
            if (password != null && !password.trim().isEmpty()) {
                tk.setPassword(password);
            }
            tk.setRole(role);
            repo.save(tk);
        }
    }

    /**
     * Xóa tài khoản theo username
     */
    public void deleteByUsername(String username) {
        repo.deleteByUsername(username);
    }

    /**
     * Đăng nhập: kiểm tra username và password có hợp lệ không
     */
    public TaiKhoan dangNhap(String username, String password) {
        TaiKhoan tk = repo.findByUsername(username);
        if (tk != null && tk.getPassword().equals(password)) {
            return tk; // đăng nhập thành công
        }
        return null; // sai tài khoản hoặc mật khẩu
    }
}
