package vn.edu.quanlynhatro.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import vn.edu.quanlynhatro.model.SinhVien;
import vn.edu.quanlynhatro.service.SinhVienService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/sinhvien")
public class SinhVienController {

    @Autowired
    private SinhVienService sinhVienService;

    // ✅ 1. Lấy danh sách tất cả sinh viên
    @GetMapping("/all")
    public ResponseEntity<List<SinhVien>> getAllSinhVien() {
        try {
            List<SinhVien> sinhVienList = sinhVienService.getAllSinhVien();
            return ResponseEntity.ok(sinhVienList);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // ✅ 2. Tìm sinh viên theo MSSV
    @GetMapping("/{mssv}")
    public ResponseEntity<SinhVien> getSinhVienByMssv(@PathVariable String mssv) {
        try {
            SinhVien sinhVien = sinhVienService.findByMssv(mssv);
            if (sinhVien != null) {
                return ResponseEntity.ok(sinhVien);
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // ✅ 3. Thêm sinh viên mới
    @PostMapping("/save")
    public ResponseEntity<Map<String, Object>> createSinhVien(@RequestBody SinhVien sinhVien) {
        Map<String, Object> response = new HashMap<>();
        try {
            // Kiểm tra MSSV không được trống
            if (sinhVien.getMssv() == null || sinhVien.getMssv().trim().isEmpty()) {
                response.put("success", false);
                response.put("message", "MSSV không được để trống");
                return ResponseEntity.badRequest().body(response);
            }

            // Kiểm tra MSSV đã tồn tại chưa
            SinhVien existing = sinhVienService.findByMssv(sinhVien.getMssv());
            if (existing != null) {
                response.put("success", false);
                response.put("message", "MSSV đã tồn tại trong hệ thống");
                return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
            }

            // Lưu sinh viên
            sinhVienService.saveSinhVien(sinhVien);
            
            response.put("success", true);
            response.put("message", "Thêm sinh viên thành công");
            response.put("sinhVien", sinhVien);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Lỗi khi thêm sinh viên: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // ✅ 4. Cập nhật thông tin sinh viên
    @PutMapping("/save")
    public ResponseEntity<Map<String, Object>> updateSinhVien(@RequestBody SinhVien sinhVien) {
        Map<String, Object> response = new HashMap<>();
        try {
            // Kiểm tra sinh viên có tồn tại không
            SinhVien existing = sinhVienService.findByMssv(sinhVien.getMssv());
            if (existing == null) {
                response.put("success", false);
                response.put("message", "Không tìm thấy sinh viên để cập nhật");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }

            // Cập nhật thông tin
            sinhVien.setId(existing.getId()); // Giữ nguyên ID
            sinhVienService.saveSinhVien(sinhVien);
            
            response.put("success", true);
            response.put("message", "Cập nhật thông tin sinh viên thành công");
            response.put("sinhVien", sinhVien);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Lỗi khi cập nhật sinh viên: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // ✅ 5. Xóa sinh viên theo MSSV
    @DeleteMapping("/delete/{mssv}")
    public ResponseEntity<Map<String, Object>> deleteSinhVien(@PathVariable String mssv) {
        Map<String, Object> response = new HashMap<>();
        try {
            SinhVien existing = sinhVienService.findByMssv(mssv);
            if (existing == null) {
                response.put("success", false);
                response.put("message", "Không tìm thấy sinh viên để xóa");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }

            sinhVienService.deleteSinhVien(mssv);
            
            response.put("success", true);
            response.put("message", "Xóa sinh viên thành công");
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Lỗi khi xóa sinh viên: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // ✅ 6. Tìm kiếm sinh viên theo tên
    @GetMapping("/search")
    public ResponseEntity<List<SinhVien>> searchSinhVien(@RequestParam String keyword) {
        try {
            List<SinhVien> result = sinhVienService.searchByHoTen(keyword);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // ✅ 7. Lấy sinh viên theo lớp
    @GetMapping("/lop/{lop}")
    public ResponseEntity<List<SinhVien>> getSinhVienByLop(@PathVariable String lop) {
        try {
            List<SinhVien> sinhVienList = sinhVienService.findByLop(lop);
            return ResponseEntity.ok(sinhVienList);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // ✅ 8. Lấy sinh viên theo ngành học
    @GetMapping("/nganh/{nganhHoc}")
    public ResponseEntity<List<SinhVien>> getSinhVienByNganh(@PathVariable String nganhHoc) {
        try {
            List<SinhVien> sinhVienList = sinhVienService.findByNganhHoc(nganhHoc);
            return ResponseEntity.ok(sinhVienList);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}