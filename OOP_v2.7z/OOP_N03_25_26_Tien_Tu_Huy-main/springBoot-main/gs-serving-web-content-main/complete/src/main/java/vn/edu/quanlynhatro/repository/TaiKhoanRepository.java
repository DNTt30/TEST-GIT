package vn.edu.quanlynhatro.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import vn.edu.quanlynhatro.model.TaiKhoan;

public interface TaiKhoanRepository extends JpaRepository<TaiKhoan, Long> {
    TaiKhoan findByUsername(String username);
    void deleteByUsername(String username);
}
