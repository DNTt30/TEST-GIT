package vn.edu.quanlynhatro.model;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "hop_dong")
public class HopDong implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private String maHopDong;

    private String maSV;      // liên kết với SinhVien
    private String maPhong;   // liên kết với Phong

    @Temporal(TemporalType.DATE)
    private Date ngayBatDau;

    @Temporal(TemporalType.DATE)
    private Date ngayKetThuc;

    private double tienCoc;
    private String trangThai;

    // --- Constructors ---
    public HopDong() {}

    public HopDong(String maHopDong, String maSV, String maPhong, Date ngayBatDau, Date ngayKetThuc,
                   double tienCoc, String trangThai) {
        this.maHopDong = maHopDong;
        this.maSV = maSV;
        this.maPhong = maPhong;
        this.ngayBatDau = ngayBatDau;
        this.ngayKetThuc = ngayKetThuc;
        this.tienCoc = tienCoc;
        this.trangThai = trangThai;
    }

    // --- Getters & Setters ---
    public String getMaHopDong() { return maHopDong; }
    public void setMaHopDong(String maHopDong) { this.maHopDong = maHopDong; }
    public String getMaSV() { return maSV; }
    public void setMaSV(String maSV) { this.maSV = maSV; }
    public String getMaPhong() { return maPhong; }
    public void setMaPhong(String maPhong) { this.maPhong = maPhong; }
    public Date getNgayBatDau() { return ngayBatDau; }
    public void setNgayBatDau(Date ngayBatDau) { this.ngayBatDau = ngayBatDau; }
    public Date getNgayKetThuc() { return ngayKetThuc; }
    public void setNgayKetThuc(Date ngayKetThuc) { this.ngayKetThuc = ngayKetThuc; }
    public double getTienCoc() { return tienCoc; }
    public void setTienCoc(double tienCoc) { this.tienCoc = tienCoc; }
    public String getTrangThai() { return trangThai; }
    public void setTrangThai(String trangThai) { this.trangThai = trangThai; }

    @Override
    public String toString() {
        return "HopDong{" +
                "maHopDong='" + maHopDong + '\'' +
                ", maSV='" + maSV + '\'' +
                ", maPhong='" + maPhong + '\'' +
                ", trangThai='" + trangThai + '\'' +
                '}';
    }
}
