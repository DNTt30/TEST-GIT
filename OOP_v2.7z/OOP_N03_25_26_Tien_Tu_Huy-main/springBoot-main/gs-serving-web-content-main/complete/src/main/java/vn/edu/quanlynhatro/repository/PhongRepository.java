package vn.edu.quanlynhatro.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import vn.edu.quanlynhatro.model.Phong;

import java.util.List;

public interface PhongRepository extends JpaRepository<Phong, String> {
    
    // Tìm phòng theo số phòng
    Phong findBySoPhong(String soPhong);
    
    // Tìm phòng theo trạng thái
    List<Phong> findByTrangThai(boolean trangThai);
    
    // Tìm phòng trống
    List<Phong> findByTrangThaiFalse();
    
    // Tìm phòng đang sử dụng
    List<Phong> findByTrangThaiTrue();
    
    // Tìm kiếm phòng theo số phòng
    @Query("SELECT p FROM Phong p WHERE p.soPhong LIKE %:keyword%")
    List<Phong> searchBySoPhong(@Param("keyword") String keyword);
    
    // Kiểm tra phòng có tồn tại không
    boolean existsBySoPhong(String soPhong);
}