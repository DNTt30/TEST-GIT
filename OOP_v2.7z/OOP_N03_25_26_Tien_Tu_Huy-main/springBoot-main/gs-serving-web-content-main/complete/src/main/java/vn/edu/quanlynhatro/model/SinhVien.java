package vn.edu.quanlynhatro.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "sinh_vien")
public class SinhVien extends Nguoi {

    private String mssv;
    private String queQuan;
    private String sdt;
    private String cccd;
    private String lop;
    private String nganhHoc;

    // --- Constructors ---
    public SinhVien() {}

    public SinhVien(String hoTen, String gioiTinh, java.util.Date ngaySinh, String diaChi,
                     String mssv, String queQuan, String sdt, String cccd, String lop, String nganhHoc) {
        super(hoTen, gioiTinh, ngaySinh, diaChi);
        this.mssv = mssv;
        this.queQuan = queQuan;
        this.sdt = sdt;
        this.cccd = cccd;
        this.lop = lop;
        this.nganhHoc = nganhHoc;
    }

    // --- Getters & Setters ---
    public String getMssv() { return mssv; }
    public void setMssv(String mssv) { this.mssv = mssv; }
    public String getQueQuan() { return queQuan; }
    public void setQueQuan(String queQuan) { this.queQuan = queQuan; }
    public String getSdt() { return sdt; }
    public void setSdt(String sdt) { this.sdt = sdt; }
    public String getCccd() { return cccd; }
    public void setCccd(String cccd) { this.cccd = cccd; }
    public String getLop() { return lop; }
    public void setLop(String lop) { this.lop = lop; }
    public String getNganhHoc() { return nganhHoc; }
    public void setNganhHoc(String nganhHoc) { this.nganhHoc = nganhHoc; }

    @Override
    public String toString() {
        return "SinhVien{" +
                "id=" + getId() +
                ", hoTen='" + getHoTen() + '\'' +
                ", mssv='" + mssv + '\'' +
                '}';
    }
}
