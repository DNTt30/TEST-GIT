package vn.edu.quanlynhatro.model;

import jakarta.persistence.*; // Hoặc javax.persistence.* nếu bạn dùng phiên bản cũ
import java.io.Serializable;

/**
 * Lớp TaiKhoan đại diện cho một bảng trong cơ sở dữ liệu
 */
@Entity // ✅ BÁO HIỆU: Đây là một Entity, tương ứng với một bảng trong DB
@Table(name = "tai_khoan") // ✅ Tùy chọn: Đặt tên cụ thể cho bảng
public class TaiKhoan implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id // ✅ BÁO HIỆU: Đây là khóa chính
    @GeneratedValue(strategy = GenerationType.IDENTITY) // ✅ BÁO HIỆU: ID sẽ được tự động tăng
    private Long id; // Thêm trường ID

    private String username;
    private String password;
    private String role;

    // --- Constructors ---
    public TaiKhoan() {
    }

    public TaiKhoan(String username, String password, String role) {
        this.username = username;
        this.password = password;
        this.role = role;
    }

    // --- Getters & Setters ---

    // ✅ Thêm Getter & Setter cho ID
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }


    @Override
    public String toString() {
        return "TaiKhoan{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", role='" + role + '\'' +
                '}';
    }
}