package vn.edu.quanlynhatro.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import vn.edu.quanlynhatro.model.Phong;
import vn.edu.quanlynhatro.repository.PhongRepository;

import java.util.List;
import java.util.Optional;

@Service
public class PhongService {

    @Autowired
    private PhongRepository phongRepository;

    // Lấy tất cả phòng
    public List<Phong> getAllPhong() {
        return phongRepository.findAll();
    }

    // Tìm phòng theo số phòng
    public Phong findBySoPhong(String soPhong) {
        return phongRepository.findBySoPhong(soPhong);
    }

    // Lưu phòng
    public Phong savePhong(Phong phong) {
        return phongRepository.save(phong);
    }

    // Xóa phòng
    public void deletePhong(String soPhong) {
        phongRepository.deleteById(soPhong);
    }

    // Lấy phòng trống
    public List<Phong> getPhongTrong() {
        return phongRepository.findByTrangThaiFalse();
    }

    // Lấy phòng đang sử dụng
    public List<Phong> getPhongDangSuDung() {
        return phongRepository.findByTrangThaiTrue();
    }

    // Tìm kiếm phòng
    public List<Phong> searchPhong(String keyword) {
        return phongRepository.searchBySoPhong(keyword);
    }

    // Kiểm tra phòng có tồn tại không
    public boolean existsBySoPhong(String soPhong) {
        return phongRepository.existsBySoPhong(soPhong);
    }

    // Cập nhật trạng thái phòng
    public boolean updateTrangThai(String soPhong, boolean trangThai) {
        Phong phong = phongRepository.findBySoPhong(soPhong);
        if (phong != null) {
            phong.setTrangThai(trangThai);
            phongRepository.save(phong);
            return true;
        }
        return false;
    }

    // Cập nhật tiền điện nước
    public boolean updateTienDienNuoc(String soPhong, double tienDienNuoc) {
        Phong phong = phongRepository.findBySoPhong(soPhong);
        if (phong != null) {
            phong.setTienDienNuoc(tienDienNuoc);
            phongRepository.save(phong);
            return true;
        }
        return false;
    }
}