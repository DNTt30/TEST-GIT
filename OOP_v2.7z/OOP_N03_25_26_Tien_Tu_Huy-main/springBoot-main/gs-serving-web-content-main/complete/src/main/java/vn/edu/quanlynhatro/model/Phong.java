package vn.edu.quanlynhatro.model;

import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "phong")
public class Phong implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private String soPhong; // Số phòng là khóa chính

    private boolean trangThai; // true = đang sử dụng, false = trống
    private double tienDienNuoc;

    // --- Constructors ---
    public Phong() {}

    public Phong(String soPhong, boolean trangThai, double tienDienNuoc) {
        this.soPhong = soPhong;
        this.trangThai = trangThai;
        this.tienDienNuoc = tienDienNuoc;
    }

    // --- Getters & Setters ---
    public String getSoPhong() { return soPhong; }
    public void setSoPhong(String soPhong) { this.soPhong = soPhong; }
    public boolean isTrangThai() { return trangThai; }
    public void setTrangThai(boolean trangThai) { this.trangThai = trangThai; }
    public double getTienDienNuoc() { return tienDienNuoc; }
    public void setTienDienNuoc(double tienDienNuoc) { this.tienDienNuoc = tienDienNuoc; }

    @Override
    public String toString() {
        return "Phong{" +
                "soPhong='" + soPhong + '\'' +
                ", trangThai=" + trangThai +
                ", tienDienNuoc=" + tienDienNuoc +
                '}';
    }
}
