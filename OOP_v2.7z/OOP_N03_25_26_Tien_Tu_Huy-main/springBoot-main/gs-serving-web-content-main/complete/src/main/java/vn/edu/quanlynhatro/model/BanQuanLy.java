package vn.edu.quanlynhatro.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "ban_quan_ly")
public class BanQuanLy extends Nguoi {

    private String cccd;
    private String soDienThoai;

    // --- Constructors ---
    public BanQuanLy() {}

    public BanQuanLy(String hoTen, String gioiTinh, java.util.Date ngaySinh, String diaChi,
                     String cccd, String soDienThoai) {
        super(hoTen, gioiTinh, ngaySinh, diaChi);
        this.cccd = cccd;
        this.soDienThoai = soDienThoai;
    }

    // --- Getters & Setters ---
    public String getCccd() { return cccd; }
    public void setCccd(String cccd) { this.cccd = cccd; }
    public String getSoDienThoai() { return soDienThoai; }
    public void setSoDienThoai(String soDienThoai) { this.soDienThoai = soDienThoai; }

    @Override
    public String toString() {
        return "BanQuanLy{" +
                "id=" + getId() +
                ", hoTen='" + getHoTen() + '\'' +
                ", cccd='" + cccd + '\'' +
                ", soDienThoai='" + soDienThoai + '\'' +
                '}';
    }
}
