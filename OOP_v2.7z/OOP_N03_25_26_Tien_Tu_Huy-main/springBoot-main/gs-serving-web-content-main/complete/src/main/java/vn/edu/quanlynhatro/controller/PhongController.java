package vn.edu.quanlynhatro.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import vn.edu.quanlynhatro.model.Phong;
import vn.edu.quanlynhatro.service.PhongService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/phong")
@CrossOrigin(origins = "*")
public class PhongController {

    @Autowired
    private PhongService phongService;

    // 1. Lấy danh sách tất cả phòng
    @GetMapping("/all")
    public ResponseEntity<List<Phong>> getAllPhong() {
        try {
            List<Phong> phongList = phongService.getAllPhong();
            return ResponseEntity.ok(phongList);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // 2. Lấy thông tin phòng theo số phòng
    @GetMapping("/{soPhong}")
    public ResponseEntity<Phong> getPhongBySoPhong(@PathVariable String soPhong) {
        try {
            Phong phong = phongService.findBySoPhong(soPhong);
            if (phong != null) {
                return ResponseEntity.ok(phong);
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // 3. Thêm phòng mới
    @PostMapping("/save")
    public ResponseEntity<Map<String, Object>> createPhong(@RequestBody Phong phong) {
        Map<String, Object> response = new HashMap<>();
        try {
            // Kiểm tra số phòng không được trống
            if (phong.getSoPhong() == null || phong.getSoPhong().trim().isEmpty()) {
                response.put("success", false);
                response.put("message", "Số phòng không được để trống");
                return ResponseEntity.badRequest().body(response);
            }

            // Kiểm tra số phòng đã tồn tại chưa
            if (phongService.existsBySoPhong(phong.getSoPhong())) {
                response.put("success", false);
                response.put("message", "Số phòng đã tồn tại trong hệ thống");
                return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
            }

            // Lưu phòng
            Phong savedPhong = phongService.savePhong(phong);
            
            response.put("success", true);
            response.put("message", "Thêm phòng thành công");
            response.put("phong", savedPhong);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Lỗi khi thêm phòng: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // 4. Cập nhật thông tin phòng
    @PutMapping("/save")
    public ResponseEntity<Map<String, Object>> updatePhong(@RequestBody Phong phong) {
        Map<String, Object> response = new HashMap<>();
        try {
            // Kiểm tra phòng có tồn tại không
            Phong existing = phongService.findBySoPhong(phong.getSoPhong());
            if (existing == null) {
                response.put("success", false);
                response.put("message", "Không tìm thấy phòng để cập nhật");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }

            // Cập nhật phòng
            Phong updatedPhong = phongService.savePhong(phong);
            
            response.put("success", true);
            response.put("message", "Cập nhật thông tin phòng thành công");
            response.put("phong", updatedPhong);
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Lỗi khi cập nhật phòng: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // 5. Xóa phòng
    @DeleteMapping("/delete/{soPhong}")
    public ResponseEntity<Map<String, Object>> deletePhong(@PathVariable String soPhong) {
        Map<String, Object> response = new HashMap<>();
        try {
            Phong existing = phongService.findBySoPhong(soPhong);
            if (existing == null) {
                response.put("success", false);
                response.put("message", "Không tìm thấy phòng để xóa");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }

            phongService.deletePhong(soPhong);
            
            response.put("success", true);
            response.put("message", "Xóa phòng thành công");
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Lỗi khi xóa phòng: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // 6. Tìm kiếm phòng
    @GetMapping("/search")
    public ResponseEntity<List<Phong>> searchPhong(@RequestParam String keyword) {
        try {
            List<Phong> result = phongService.searchPhong(keyword);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // 7. Lấy danh sách phòng trống
    @GetMapping("/trong")
    public ResponseEntity<List<Phong>> getPhongTrong() {
        try {
            List<Phong> phongTrong = phongService.getPhongTrong();
            return ResponseEntity.ok(phongTrong);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // 8. Lấy danh sách phòng đang sử dụng
    @GetMapping("/dangsudung")
    public ResponseEntity<List<Phong>> getPhongDangSuDung() {
        try {
            List<Phong> phongDangSuDung = phongService.getPhongDangSuDung();
            return ResponseEntity.ok(phongDangSuDung);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // 9. Cập nhật trạng thái phòng
    @PutMapping("/updatetrangthai/{soPhong}")
    public ResponseEntity<Map<String, Object>> updateTrangThai(
            @PathVariable String soPhong, 
            @RequestParam boolean trangThai) {
        
        Map<String, Object> response = new HashMap<>();
        try {
            boolean success = phongService.updateTrangThai(soPhong, trangThai);
            if (success) {
                response.put("success", true);
                response.put("message", "Cập nhật trạng thái phòng thành công");
                return ResponseEntity.ok(response);
            } else {
                response.put("success", false);
                response.put("message", "Không tìm thấy phòng");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Lỗi khi cập nhật trạng thái: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // 10. Cập nhật tiền điện nước
    @PutMapping("/updatetien/{soPhong}")
    public ResponseEntity<Map<String, Object>> updateTienDienNuoc(
            @PathVariable String soPhong, 
            @RequestParam double tienDienNuoc) {
        
        Map<String, Object> response = new HashMap<>();
        try {
            boolean success = phongService.updateTienDienNuoc(soPhong, tienDienNuoc);
            if (success) {
                response.put("success", true);
                response.put("message", "Cập nhật tiền điện nước thành công");
                return ResponseEntity.ok(response);
            } else {
                response.put("success", false);
                response.put("message", "Không tìm thấy phòng");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Lỗi khi cập nhật tiền điện nước: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // 11. Lấy tổng số phòng
    @GetMapping("/count")
    public ResponseEntity<Map<String, Object>> getCount() {
        Map<String, Object> response = new HashMap<>();
        try {
            List<Phong> allPhong = phongService.getAllPhong();
            List<Phong> phongTrong = phongService.getPhongTrong();
            List<Phong> phongDangSuDung = phongService.getPhongDangSuDung();
            
            response.put("success", true);
            response.put("tongPhong", allPhong.size());
            response.put("phongTrong", phongTrong.size());
            response.put("phongDangSuDung", phongDangSuDung.size());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Lỗi khi lấy thống kê: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }
}