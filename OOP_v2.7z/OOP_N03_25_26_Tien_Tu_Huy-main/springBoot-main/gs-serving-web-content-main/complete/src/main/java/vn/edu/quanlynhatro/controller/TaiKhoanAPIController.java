package vn.edu.quanlynhatro.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import vn.edu.quanlynhatro.model.TaiKhoan;
import vn.edu.quanlynhatro.service.TaiKhoanService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
public class TaiKhoanAPIController {

    @Autowired
    private TaiKhoanService taiKhoanService;

    // ✅ 1. Lấy danh sách tài khoản
    @GetMapping("/users/all")
    public ResponseEntity<List<TaiKhoan>> getAllUsers() {
        return ResponseEntity.ok(taiKhoanService.getAllTaiKhoan());
    }

    // ✅ 2. Thêm tài khoản mới
    @PostMapping("/users/save")
    public ResponseEntity<Map<String, Object>> createUser(@RequestBody TaiKhoan taiKhoan) {
        Map<String, Object> response = new HashMap<>();
        try {
            if (taiKhoan.getUsername() == null || taiKhoan.getUsername().trim().isEmpty()) {
                response.put("message", "Tên đăng nhập không được để trống");
                return ResponseEntity.badRequest().body(response);
            }

            TaiKhoan existing = taiKhoanService.timKiemTheoUsername(taiKhoan.getUsername());
            if (existing != null) {
                response.put("message", "Tài khoản đã tồn tại!");
                return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
            }

            taiKhoanService.dangKy(taiKhoan);
            response.put("message", "Thêm tài khoản thành công!");
            response.put("users", taiKhoanService.getAllTaiKhoan());
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("message", "Lỗi khi thêm tài khoản: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // ✅ 3. Cập nhật tài khoản (chỉ dùng khi username đã tồn tại)
    @PutMapping("/users/save")
    public ResponseEntity<Map<String, Object>> updateUser(@RequestBody TaiKhoan taiKhoan) {
        Map<String, Object> response = new HashMap<>();
        try {
            TaiKhoan existing = taiKhoanService.timKiemTheoUsername(taiKhoan.getUsername());
            if (existing == null) {
                response.put("message", "Không tìm thấy tài khoản để cập nhật!");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }

            taiKhoanService.updateUser(taiKhoan.getUsername(), taiKhoan.getPassword(), taiKhoan.getRole());
            response.put("message", "Cập nhật tài khoản thành công!");
            response.put("users", taiKhoanService.getAllTaiKhoan());
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("message", "Lỗi khi cập nhật: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // ✅ 4. Xóa tài khoản
    @DeleteMapping("/users/delete/{username}")
    public ResponseEntity<Map<String, Object>> deleteUser(@PathVariable String username) {
        Map<String, Object> response = new HashMap<>();
        try {
            TaiKhoan existing = taiKhoanService.timKiemTheoUsername(username);
            if (existing == null) {
                response.put("message", "Không tìm thấy tài khoản để xóa!");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }

            taiKhoanService.deleteByUsername(username);
            response.put("message", "Xóa tài khoản thành công!");
            response.put("users", taiKhoanService.getAllTaiKhoan());
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            response.put("message", "Lỗi khi xóa tài khoản: " + e.getMessage());
            e.printStackTrace(); // In log để dễ debug
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

}
