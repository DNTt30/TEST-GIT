package vn.edu.quanlynhatro.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import vn.edu.quanlynhatro.model.SinhVien;

import java.util.List;
import java.util.Optional;

@Repository
public interface SinhVienRepository extends JpaRepository<SinhVien, Long> {
    
    // Tìm theo MSSV chính xác
    Optional<SinhVien> findByMssv(String mssv);
    
    // Kiểm tra tồn tại MSSV
    boolean existsByMssv(String mssv);
    
    // Tìm kiếm theo MSSV hoặc họ tên
    @Query("SELECT sv FROM SinhVien sv WHERE " +
           "LOWER(sv.mssv) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(sv.hoTen) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<SinhVien> findByMssvOrHoTenContaining(@Param("keyword") String keyword);
    
    // Tìm theo lớp
    List<SinhVien> findByLop(String lop);
    
    // Tìm theo ngành học
    List<SinhVien> findByNganhHoc(String nganhHoc);
    
    // Tìm theo quê quán
    List<SinhVien> findByQueQuanContaining(String queQuan);
}