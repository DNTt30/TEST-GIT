package vn.edu.quanlynhatro.service;

import vn.edu.quanlynhatro.model.Phong;
import java.util.ArrayList;

public class PhongTest {
    public static void main(String[] args) {
        // Tạo đối tượng phòng
        Phong p1 = new Phong("P101", true, 500000);
        Phong p2 = new Phong("P102", false, 300000);

        // Danh sách phòng
        ArrayList<Phong> listPhong = new ArrayList<>();
        listPhong.add(p1);
        listPhong.add(p2);

        // In ra thông tin
        for (Phong p : listPhong) {
            p.hienThiThongTin();
            // hoặc: System.out.println(p);  // dùng toString()
        }
    }
}
