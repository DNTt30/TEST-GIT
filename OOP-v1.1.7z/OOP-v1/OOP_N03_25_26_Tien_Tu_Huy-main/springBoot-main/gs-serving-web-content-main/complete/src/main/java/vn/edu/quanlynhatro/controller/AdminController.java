package vn.edu.quanlynhatro.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/admin/dashboard") // Tiền tố chung cho tất cả các URL trong class này
public class AdminController {

    // Phương thức này giờ sẽ xử lý đúng URL: /admin/dashboard/users
    @GetMapping("/users")
    public String getUserList(HttpSession session, Model model) {
        String username = (String) session.getAttribute("username");
        String role = (String) session.getAttribute("role");

        if (username == null) {
            return "redirect:/login"; // Chưa đăng nhập, chuyển hướng về trang login
        }
        if (!"Admin".equalsIgnoreCase(role)) {
            return "redirect:/access-denied"; // Không phải Admin, từ chối truy cập
        }

        // Thêm các thuộc tính cho view
        model.addAttribute("username", username);
        model.addAttribute("role", role);
        
        // (Bước sau) Tại đây bạn sẽ lấy danh sách người dùng từ database
        // List<User> userList = userService.findAll();
        // model.addAttribute("users", userList);

        // Trả về file HTML tương ứng
        return "admin/users"; 
    }

    // Các phương thức khác cho việc thêm, sửa, xóa người dùng có thể được thêm vào đây
}