package vn.edu.quanlynhatro.model;

public enum Role {
    ADMIN,
    MANAGER,
    STUDENT
}